const express = require("express");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
const { execute, SUPPORTED_LANGUAGES } = require("./executors");

const app = express();
const PORT = process.env.PORT || 5000;
const MAX_CODE_LENGTH = 50000; // characters
const MAX_INPUT_LENGTH = 20000;

app.use(cors());
app.use(express.json({ limit: "1mb" }));

// Basic abuse protection. Tune per your traffic / add auth for stricter limits.
const executeLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 20, // 20 executions per minute per IP
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many execution requests. Please slow down." },
});

app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

app.get("/api/languages", (req, res) => {
  const languages = Object.entries(SUPPORTED_LANGUAGES).map(([id, meta]) => ({
    id,
    label: meta.label,
  }));
  res.json({ languages });
});

app.post("/api/execute", executeLimiter, async (req, res) => {
  const { language, code, input } = req.body || {};

  if (!language || typeof language !== "string") {
    return res.status(400).json({ error: "Missing or invalid 'language'." });
  }
  if (!SUPPORTED_LANGUAGES[language]) {
    return res.status(400).json({
      error: `Unsupported language '${language}'. Supported: ${Object.keys(
        SUPPORTED_LANGUAGES
      ).join(", ")}`,
    });
  }
  if (typeof code !== "string" || code.trim() === "") {
    return res.status(400).json({ error: "Missing or empty 'code'." });
  }
  if (code.length > MAX_CODE_LENGTH) {
    return res.status(400).json({ error: `Code exceeds ${MAX_CODE_LENGTH} character limit.` });
  }
  const safeInput = typeof input === "string" ? input.slice(0, MAX_INPUT_LENGTH) : "";

  try {
    const start = Date.now();
    const result = await execute(language, code, safeInput);
    const durationMs = Date.now() - start;

    res.json({
      stdout: result.stdout || "",
      stderr: result.stderr || "",
      exitCode: result.exitCode,
      timedOut: !!result.timedOut,
      stage: result.stage || "run",
      durationMs,
    });
  } catch (err) {
    console.error("Execution error:", err);
    res.status(500).json({ error: "Internal error while executing code." });
  }
});

app.listen(PORT, () => {
  console.log(`Online compiler backend running on http://localhost:${PORT}`);
});
