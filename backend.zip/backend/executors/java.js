const fs = require("fs");
const path = require("path");
const { runProcess } = require("./runner");

function detectClassName(code) {
  const publicMatch = code.match(/public\s+class\s+([A-Za-z_$][A-Za-z0-9_$]*)/);
  if (publicMatch) return publicMatch[1];
  const anyMatch = code.match(/class\s+([A-Za-z_$][A-Za-z0-9_$]*)/);
  if (anyMatch) return anyMatch[1];
  return "Main";
}

async function runJava(code, input, workDir) {
  const className = detectClassName(code);
  const srcPath = path.join(workDir, `${className}.java`);
  fs.writeFileSync(srcPath, code);

  const compile = await runProcess({
    command: "javac",
    args: [srcPath],
    cwd: workDir,
    timeoutMs: 20000,
  });

  if (compile.exitCode !== 0) {
    return {
      stdout: "",
      stderr: compile.stderr || "Compilation failed",
      exitCode: compile.exitCode,
      timedOut: compile.timedOut,
      stage: "compile",
    };
  }

  const run = await runProcess({
    command: "java",
    args: ["-cp", workDir, className],
    cwd: workDir,
    input,
    timeoutMs: 10000,
  });

  return { ...run, stage: "run" };
}

module.exports = runJava;
