const fs = require("fs");
const path = require("path");
const { runProcess, resolveCommand, envWithDir } = require("./runner");

const GPP_CANDIDATES = [
  "g++", // relies on PATH — works on Linux/Mac and correctly-configured Windows
  "C:\\mingw64\\bin\\g++.exe",
  "C:\\mingw64\\mingw64\\bin\\g++.exe",
  "C:\\msys64\\mingw64\\bin\\g++.exe",
  "C:\\msys64\\ucrt64\\bin\\g++.exe",
  "C:\\MinGW\\bin\\g++.exe",
  "C:\\TDM-GCC-64\\bin\\g++.exe",
];

async function runCpp(code, input, workDir) {
  const srcPath = path.join(workDir, "main.cpp");
  const binName = process.platform === "win32" ? "main.exe" : "main.out";
  const binPath = path.join(workDir, binName);
  fs.writeFileSync(srcPath, code);

  const gppCmd = await resolveCommand("g++", GPP_CANDIDATES);

  if (!gppCmd) {
    return {
      stdout: "",
      stderr:
        "g++ (C++ compiler) was not found. Install MinGW-w64 (e.g. from " +
        "winlibs.com or the MinGW-W64-builds installer) and add its bin " +
        "folder to your PATH, then restart the server. See README.md.",
      exitCode: -1,
      timedOut: false,
      stage: "setup",
    };
  }

  // If g++ was found via an absolute path (not on PATH), its sibling tools
  // (as.exe, ld.exe, cc1plus.exe) live in the same folder — make sure that
  // folder is on PATH for this call so g++ can find them.
  const toolchainEnv = path.isAbsolute(gppCmd) ? envWithDir(path.dirname(gppCmd)) : null;

  const compile = await runProcess({
    command: gppCmd,
    args: [srcPath, "-o", binPath, "-std=c++17"],
    cwd: workDir,
    timeoutMs: 15000,
    env: toolchainEnv,
  });

  if (compile.exitCode !== 0) {
    return {
      stdout: "",
      stderr: compile.stderr || "Compilation failed",
      exitCode: compile.exitCode,
      timedOut: compile.timedOut,
      stage: "compile",
    };
  }

  const run = await runProcess({
    command: binPath,
    args: [],
    cwd: workDir,
    input,
    timeoutMs: 10000,
    env: toolchainEnv, // in case the binary dynamically links mingw runtime DLLs
  });

  return { ...run, stage: "run" };
}

module.exports = runCpp;
