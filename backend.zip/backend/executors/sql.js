const initSqlJs = require("sql.js");

let SQLModulePromise = null;
function getSQL() {
  if (!SQLModulePromise) {
    SQLModulePromise = initSqlJs();
  }
  return SQLModulePromise;
}

/**
 * Runs arbitrary SQL against a fresh in-memory SQLite database.
 * Multiple statements are supported (separated by ;). The results of
 * every statement that returns rows are collected and formatted as text,
 * similar to what you'd see in a SQL console.
 */
async function runSQL(code) {
  try {
    const SQL = await getSQL();
    const db = new SQL.Database();

    let output = "";
    let hadError = false;

    try {
      // db.exec runs one or more semicolon-separated statements and
      // returns an array of { columns, values } for statements with results.
      const results = db.exec(code);

      if (results.length === 0) {
        output = "Query executed successfully. (No rows returned)";
      } else {
        results.forEach((res, idx) => {
          const { columns, values } = res;
          output += formatTable(columns, values);
          if (idx < results.length - 1) output += "\n\n";
        });
      }
    } catch (err) {
      hadError = true;
      output = err.message;
    }

    db.close();

    return {
      stdout: hadError ? "" : output,
      stderr: hadError ? output : "",
      exitCode: hadError ? 1 : 0,
      timedOut: false,
      stage: "run",
    };
  } catch (err) {
    return {
      stdout: "",
      stderr: "SQL engine failed to initialize: " + err.message,
      exitCode: -1,
      timedOut: false,
      stage: "setup",
    };
  }
}

function formatTable(columns, rows) {
  const widths = columns.map((col, i) =>
    Math.max(col.length, ...rows.map((r) => String(r[i]).length), 3)
  );

  const line = (cells) =>
    cells.map((c, i) => String(c).padEnd(widths[i])).join(" | ");

  const sep = widths.map((w) => "-".repeat(w)).join("-+-");

  let out = line(columns) + "\n" + sep;
  for (const row of rows) {
    out += "\n" + line(row);
  }
  out += `\n\n(${rows.length} row${rows.length === 1 ? "" : "s"})`;
  return out;
}

module.exports = runSQL;
