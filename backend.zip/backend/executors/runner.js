const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

const commandCache = new Map();

/**
 * Find a working executable.
 *
 * Tries:
 * 1. Command from PATH
 * 2. Absolute paths supplied in candidates
 */
async function resolveCommand(
  cacheKey,
  candidates,
  versionArgs = ["--version"]
) {
  if (commandCache.has(cacheKey)) {
    return commandCache.get(cacheKey);
  }

  for (const candidate of candidates) {
    // If candidate is an absolute path, make sure it exists.
    if (/[\\/]/.test(candidate) && !fs.existsSync(candidate)) {
      continue;
    }

    const result = await runProcess({
      command: candidate,
      args: versionArgs,
      cwd: process.cwd(),
      timeoutMs: 5000,
    });

    const failed =
      result.exitCode === -1 ||
      /ENOENT|not found|not recognized/i.test(result.stderr || "");

    if (!failed) {
      commandCache.set(cacheKey, candidate);
      return candidate;
    }
  }

  commandCache.set(cacheKey, null);
  return null;
}

/**
 * Run a process and capture stdout/stderr.
 */
function runProcess({
  command,
  args = [],
  cwd,
  input = "",
  timeoutMs = 10000,
  maxOutputBytes = 200000,
  env = null,
}) {
  return new Promise((resolve) => {
    let stdout = "";
    let stderr = "";
    let outputBytes = 0;
    let timedOut = false;
    let killedForSize = false;
    let settled = false;

    let child;

    try {
      /*
       * IMPORTANT:
       * Do NOT use cmd.exe for mcs.
       *
       * Your machine has:
       * C:\Program Files\Mono\bin\mcs
       *
       * Node.js can spawn this directly even though the path contains
       * spaces.
       */
      child = spawn(command, args, {
        cwd,
        env: env || process.env,
        shell: false,
        windowsHide: true,
      });
    } catch (err) {
      resolve({
        stdout: "",
        stderr: `Failed to start process: ${err.message}`,
        exitCode: -1,
        timedOut: false,
      });
      return;
    }

    const timer = setTimeout(() => {
      if (settled) return;

      timedOut = true;

      try {
        child.kill();
      } catch (err) {
        // Ignore kill errors
      }
    }, timeoutMs);

    /*
     * Send stdin.
     */
    if (input !== undefined && input !== null && input !== "") {
      try {
        child.stdin.write(String(input));
      } catch (err) {
        // Ignore stdin errors
      }
    }

    try {
      child.stdin.end();
    } catch (err) {
      // Ignore stdin errors
    }

    /*
     * stdout
     */
    child.stdout.on("data", (data) => {
      if (settled) return;

      outputBytes += data.length;

      if (outputBytes > maxOutputBytes) {
        killedForSize = true;

        try {
          child.kill();
        } catch (err) {
          // Ignore kill errors
        }

        return;
      }

      stdout += data.toString();
    });

    /*
     * stderr
     */
    child.stderr.on("data", (data) => {
      if (settled) return;

      outputBytes += data.length;

      if (outputBytes > maxOutputBytes) {
        killedForSize = true;

        try {
          child.kill();
        } catch (err) {
          // Ignore kill errors
        }

        return;
      }

      stderr += data.toString();
    });

    /*
     * Process error.
     */
    child.on("error", (err) => {
      if (settled) return;

      settled = true;
      clearTimeout(timer);

      resolve({
        stdout,
        stderr: stderr + `\nProcess error: ${err.message}`,
        exitCode: -1,
        timedOut,
      });
    });

    /*
     * Process finished.
     */
    child.on("close", (code) => {
      if (settled) return;

      settled = true;
      clearTimeout(timer);

      if (timedOut) {
        stderr += "\n[Execution timed out]";
      }

      if (killedForSize) {
        stderr += "\n[Output limit exceeded — process terminated]";
      }

      resolve({
        stdout,
        stderr,
        exitCode: code,
        timedOut,
      });
    });
  });
}

/**
 * Add a directory to PATH.
 *
 * Useful for compilers that depend on other executables/DLLs
 * located in the same directory.
 */
function envWithDir(dir) {
  if (!dir) {
    return process.env;
  }

  const pathKey =
    Object.keys(process.env).find(
      (key) => key.toLowerCase() === "path"
    ) || "PATH";

  return {
    ...process.env,
    [pathKey]: `${dir}${path.delimiter}${process.env[pathKey] || ""}`,
  };
}

module.exports = {
  runProcess,
  resolveCommand,
  envWithDir,
};