const fs = require("fs");
const path = require("path");
const { runProcess } = require("./runner");

async function runJavaScript(code, input, workDir) {
  const filePath = path.join(workDir, "main.js");
  fs.writeFileSync(filePath, code);

  const result = await runProcess({
    command: "node",
    args: ["--no-warnings", "main.js"],
    cwd: workDir,
    input,
    timeoutMs: 10000,
  });

  return result;
}

module.exports = runJavaScript;
