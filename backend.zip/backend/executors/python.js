const fs = require("fs");
const path = require("path");
const { runProcess } = require("./runner");

// Windows typically only has "python" on PATH (and often a Microsoft Store
// alias stub, not a real install). Linux/Mac typically have "python3".
// We detect which real command works once, then cache it.
let cachedPythonCommand = null;

function looksLikeMissingOrStoreStub(result) {
  const text = `${result.stderr || ""}`.toLowerCase();
  return (
    result.exitCode === -1 ||
    text.includes("enoent") ||
    text.includes("was not found") ||
    text.includes("install from the microsoft store")
  );
}

async function detectPythonCommand(workDir) {
  if (cachedPythonCommand) return cachedPythonCommand;

  const candidates = process.platform === "win32"
    ? ["python", "python3", "py"]
    : ["python3", "python"];

  for (const cmd of candidates) {
    const probe = await runProcess({
      command: cmd,
      args: ["--version"],
      cwd: workDir,
      timeoutMs: 5000,
    });
    if (!looksLikeMissingOrStoreStub(probe)) {
      cachedPythonCommand = cmd;
      return cmd;
    }
  }

  return null; // nothing worked
}

async function runPython(code, input, workDir) {
  const filePath = path.join(workDir, "main.py");
  fs.writeFileSync(filePath, code);

  const pythonCmd = await detectPythonCommand(workDir);

  if (!pythonCmd) {
    return {
      stdout: "",
      stderr:
        "Python was not found on this server. Install it from " +
        "https://www.python.org/downloads/ (check 'Add python.exe to PATH' " +
        "on Windows) and make sure any Windows Store app-execution-alias " +
        "for python.exe/python3.exe is turned off, then restart the server.",
      exitCode: -1,
      timedOut: false,
      stage: "setup",
    };
  }

  const args = pythonCmd === "py" ? ["-3", "main.py"] : ["main.py"];

  const result = await runProcess({
    command: pythonCmd,
    args,
    cwd: workDir,
    input,
    timeoutMs: 10000,
  });

  return result;
}

module.exports = runPython;
