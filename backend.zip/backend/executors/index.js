const fs = require("fs");
const path = require("path");
const os = require("os");
const { v4: uuidv4 } = require("uuid");

const runPython = require("./python");
const runJavaScript = require("./javascript");
const runC = require("./c");
const runCpp = require("./cpp");
const runJava = require("./java");
const runCSharp = require("./csharp");
const runSQL = require("./sql");

const SUPPORTED_LANGUAGES = {
  python: { label: "Python 3", needsWorkspace: true },
  javascript: { label: "JavaScript (Node.js)", needsWorkspace: true },
  c: { label: "C (gcc)", needsWorkspace: true },
  cpp: { label: "C++ (g++)", needsWorkspace: true },
  java: { label: "Java", needsWorkspace: true },
  sql: { label: "SQL (SQLite)", needsWorkspace: false },
};

const TEMP_ROOT = path.join(__dirname, "..", "temp");
if (!fs.existsSync(TEMP_ROOT)) fs.mkdirSync(TEMP_ROOT, { recursive: true });

function makeWorkspace() {
  const dir = path.join(TEMP_ROOT, uuidv4());
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function cleanupWorkspace(dir) {
  fs.rm(dir, { recursive: true, force: true }, () => {});
}

async function execute(language, code, input = "") {
  if (!SUPPORTED_LANGUAGES[language]) {
    return {
      stdout: "",
      stderr: `Unsupported language: ${language}`,
      exitCode: -1,
      timedOut: false,
    };
  }

  if (language === "sql") {
    return runSQL(code);
  }

  const workDir = makeWorkspace();
  try {
    switch (language) {
      case "python":
        return await runPython(code, input, workDir);
      case "javascript":
        return await runJavaScript(code, input, workDir);
      case "c":
        return await runC(code, input, workDir);
      case "cpp":
        return await runCpp(code, input, workDir);
      case "java":
        return await runJava(code, input, workDir);
      case "csharp":
        return await runCSharp(code, input, workDir);
      default:
        return {
          stdout: "",
          stderr: `No executor implemented for: ${language}`,
          exitCode: -1,
          timedOut: false,
        };
    }
  } finally {
    cleanupWorkspace(workDir);
  }
}

module.exports = { execute, SUPPORTED_LANGUAGES };
