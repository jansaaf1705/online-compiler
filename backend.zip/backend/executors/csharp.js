const fs = require("fs");
const path = require("path");
const { runProcess, resolveCommand } = require("./runner");

const MCS_CANDIDATES = [
  "mcs",
  "C:\\Program Files\\Mono\\bin\\mcs",
  "C:\\Program Files (x86)\\Mono\\bin\\mcs",
];

const MONO_CANDIDATES = [
  "mono",
  "C:\\Program Files\\Mono\\bin\\mono.exe",
  "C:\\Program Files (x86)\\Mono\\bin\\mono.exe",
];

const DOTNET_SCRIPT_CANDIDATES = ["dotnet-script"];

async function runCSharp(code, input, workDir) {
  const srcPath = path.join(workDir, "main.cs");
  const exePath = path.join(workDir, "main.exe");

  fs.writeFileSync(srcPath, code, "utf8");

  const mcsCmd = await resolveCommand(
    "mcs",
    MCS_CANDIDATES
  );

  const monoCmd = await resolveCommand(
    "mono",
    MONO_CANDIDATES
  );

  /*
   * Mono found
   */
  if (mcsCmd && monoCmd) {
    const compile = await runProcess({
      command: mcsCmd,
      args: [
        "-out:" + exePath,
        srcPath,
      ],
      cwd: workDir,
      timeoutMs: 15000,
    });

    if (compile.exitCode !== 0) {
      return {
        stdout: "",
        stderr: compile.stderr || "Compilation failed",
        exitCode: compile.exitCode,
        timedOut: compile.timedOut,
        stage: "compile",
      };
    }

    const run = await runProcess({
      command: monoCmd,
      args: [exePath],
      cwd: workDir,
      input: input || "",
      timeoutMs: 10000,
    });

    return {
      ...run,
      stage: "run",
    };
  }

  /*
   * Fallback to dotnet-script
   */
  const dotnetScriptCmd = await resolveCommand(
    "dotnet-script",
    DOTNET_SCRIPT_CANDIDATES,
    ["--version"]
  );

  if (dotnetScriptCmd) {
    const scriptPath = path.join(workDir, "main.csx");

    fs.writeFileSync(scriptPath, code, "utf8");

    const run = await runProcess({
      command: dotnetScriptCmd,
      args: [scriptPath],
      cwd: workDir,
      input: input || "",
      timeoutMs: 20000,
    });

    return {
      ...run,
      stage: "run",
    };
  }

  return {
    stdout: "",
    stderr:
      "C# compiler/runtime not found.\n\n" +
      "Expected Mono at:\n" +
      "C:\\Program Files\\Mono\\bin\\mcs\n" +
      "C:\\Program Files\\Mono\\bin\\mono.exe",
    exitCode: -1,
    timedOut: false,
    stage: "setup",
  };
}

module.exports = runCSharp;